/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author User
 */
public class Enclosure {

    private String number;
    private Dog occupant;
    private int days;
    private int price;

    public void setNumber(String numberIn) {
        number = numberIn;
    }

    public void setOccupant(Dog occupantIn) {
        occupant = occupantIn;
    }

    public void setDays(int daysIn) {
        days = daysIn;
    }

    public void setPrice(int priceIn) {
        price = priceIn;
    }

    public String getNumber() {
        return number;
    }

    public Dog getOccupant() {
        return occupant;
    }

    public int getDays() {
        return days;
    }

    public int getPrice() {
        return price;
    }

}
