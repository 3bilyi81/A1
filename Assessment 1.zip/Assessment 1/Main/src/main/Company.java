/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author User
 */
public class Company {

    private Enclosure[] space;

    public Company() {
        space = new Enclosure[10];
        
        // fill array with enclosure objects
    }

    public boolean addDog(Enclosure dogIn) {
        for (int i = 0; i < space.length; i++) {
            if (space[i] == null) {
                space[i] = dogIn;
                return true;
            }
        }
        return false;
    }

    public boolean removeDog(String number) {
        for (int i = 0; i < space.length; i++) {
            if (space[i] != null) {
                if (space[i].getNumber().equals(number)) {
                    space[i] = null;
                    return true;
                }
            }
        }
        return false;
    }
    
    public int getEmptyEnclosure()
    {
        int tally = 0;
       for(int i=0; i<space.length; i++)
   {
   if(space[i] == null)
   {
   tally++;
   }
   }
       return tally;
    }

}
