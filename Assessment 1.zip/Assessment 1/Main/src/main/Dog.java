/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author User
 */
public class Dog {
    

    private String name;
    private String ownerName;
    private int age;
    private String gender;
    private String breed;
    private String generalNotes;

    public void setName(String nameIn) {
        name = nameIn;
    }

    public void setownerName(String ownerNameIn) {
        ownerName = ownerNameIn;
    }

    public void setAge(int ageIn) {
        age = ageIn;
    }

    public void setGender(String genderIn) {
        gender = genderIn;
    }

    public void setBreed(String breedIn) {
        breed = breedIn;
    }

    public void setgeneralNotes(String generalNotesIn) {
        generalNotes = generalNotesIn;
    }

    public String getName() {
        return name;
    }

    public String getownerName() {
        return ownerName;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getBreed() {
        return breed;
    }

    public String getgeneralNotes() {
        return generalNotes;
    }
}
